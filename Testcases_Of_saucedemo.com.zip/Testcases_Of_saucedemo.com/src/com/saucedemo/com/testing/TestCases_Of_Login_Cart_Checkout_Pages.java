package com.saucedemo.com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite; 
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

//import java.util.concurrent.TimeUnit;
import java.util.regex.*;

public class TestCases_Of_Login_Cart_Checkout_Pages {

public static WebDriver driver;
public static WebElement username,password,login,addtocart,cartproductcount,cartproductimglink,cartproducttextlink,removetocart,checkCart,checkoutcart;

public static int previouscount=0,presentcount=0;
@BeforeSuite  
public void Setup()  
{  
	System.setProperty("webdriver.chrome.driver", "G:\\Java Testing\\UpdatedChromeDriver\\chromedriver.exe");  
}  

@BeforeClass
public void launchBrowser()
{
	driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://www.saucedemo.com");	
}

@Test (priority=0)
public static void fillFields() 
{
	username=driver.findElement(By.id("user-name"));
	password=driver.findElement(By.id("password"));
	login=driver.findElement(By.name("login-button"));
	username.sendKeys("standard_user");
	password.sendKeys("secret_sauce");
	
}

/* Testcase 1 : A username is considered valid if all the following constraints are satisfied:
1. The username consists of 6 to 30 characters inclusive. 
2. If the username consists of less than 6 or greater than 30 characters, then it is an invalid username.
3.The username can only contain alphanumeric characters and underscores (_). 
4.Alphanumeric characters describe the character set consisting of lowercase characters [a – z], uppercase characters [A – Z], and digits [0 – 9].
5.The first character of the username must be an alphabetic character, i.e., either lowercase character[a – z] or uppercase character [A – Z]. */

@Test (priority=1)
public static void isValidUsername()
{
    boolean res;
	// Regex to check valid username.
    String regex = "^[A-Za-z]\\w{5,29}$";

    // Compile the ReGex
    Pattern p = Pattern.compile(regex);

    // If the username is empty return false
    //if (username == null) { res= false; }
    //System.out.println("username value" + username);

    // Pattern class contains matcher() method to find matching between given username and regular expression.
    Matcher m = p.matcher(username.getAttribute("value"));
    
    //System.out.println("PASSWORD IS " +password.getAttribute("value"));

    // Return if the username matched the ReGex
    res= m.matches();
    if(res)
    	System.out.println("Valid Username");
    else
    {
    	System.out.println("Invalid Username");
    	//driver.navigate().to("https://www.saucedemo.com"); 
    }
}

@Test (priority=2)
public void isPasswordMasked() {
	if(password.getAttribute("type").equals("password"))
		System.out.println("Password is masked");
	else
		System.out.println("Password is not masked");
	
}

@Test (priority=3)
public void isUsernamePasswordBlank() {
	if((username.getAttribute("value").equals(""))||(password.getAttribute("value").equals("")))
		System.out.println("Username & Passwords can't be blank");
	else
		System.out.println("Username & Password are Non Blank");
	
}

@Test (priority=4)
public void isPasswordInvalid() {
	if(((username.getAttribute("value").equals("standard_user"))||(username.getAttribute("value").equals("locked_out_user"))||(username.getAttribute("value").equals("problem_user"))||(username.getAttribute("value").equals("performance_glitch_user"))) && (!(password.getAttribute("value").equals("secret_sauce")))) 
		System.out.println("Valid Username & Invalid password");
	else
		System.out.println("Valid Username & Password");
	
}

@Test (priority=5)
public void isUsernameInvalid() {
	if (!((username.getAttribute("value").equals("standard_user"))||(username.getAttribute("value").equals("locked_out_user"))||(username.getAttribute("value").equals("problem_user"))||(username.getAttribute("value").equals("performance_glitch_user"))) && (password.getAttribute("value").equals("secret_sauce"))) 
		System.out.println("InValid Username & Valid password");
	else
		System.out.println("Valid Username & Password");
	
}

@Test (priority=6)
public void isUsernameAndPasswordIsValid() {
	if (((username.getAttribute("value").equals("standard_user"))||(username.getAttribute("value").equals("locked_out_user"))||(username.getAttribute("value").equals("problem_user"))||(username.getAttribute("value").equals("performance_glitch_user"))) && (password.getAttribute("value").equals("secret_sauce"))) 
		System.out.println("Valid Username & Valid password");
	}

@Test (priority=7)
public void login() {
login.click();
String actualUrl="https://www.saucedemo.com/inventory.html";
String expectedUrl= driver.getCurrentUrl();
Assert.assertEquals(expectedUrl,actualUrl);
}

@Test (priority=8)
public static void isAddtocartDisplay()
{
	addtocart=driver.findElement(By.id("add-to-cart-sauce-labs-backpack"));
	if(addtocart.isDisplayed())
		System.out.println("Add to cart of sauce labs backpack is displayed");
	else
		System.out.println("Add to cart of sauce labs backpack is not displayed");
}	
    
@Test (priority=9 )
public static void isAddtocartEnable()
{
    addtocart=driver.findElement(By.id("add-to-cart-sauce-labs-backpack")); 
    //cartproductcount=driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a"));
	//cartproductcount=driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/span"));
	
	//previouscount=Integer.parseInt(cartproductcount.getText());
    previouscount=0;
    if(addtocart.isEnabled())
		{ System.out.println("Add to cart of sauce labs backpack is enabled"); addtocart.click();}
	else
		System.out.println("Add to cart of sauce labs backpack is not enabled");	
}
    
@Test (priority=10)
public static void AddProductToCart()
{
	cartproductcount=driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/span"));
	presentcount=Integer.parseInt(cartproductcount.getText());
	if(previouscount<presentcount)
		System.out.println("Products are added in the cart");
	else
		System.out.println("Products are not added in the cart");
}

@Test (priority=11)
public static void CartProductImage()
{
	//*[@id="item_4_img_link"]/img
	cartproductimglink=driver.findElement(By.xpath("//*[@id=\"item_4_img_link\"]/img"));
	if(cartproductimglink.isDisplayed())
	{
		cartproductimglink.click();
		driver.findElement(By.id("back-to-products")).click();
		//fillFields();		
	}
	else
		System.out.println("Product Image not found");
}

@Test (priority=12)
public static void CartProductText()
{
	cartproducttextlink=driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div"));
	if(cartproducttextlink.isDisplayed())
	{
		cartproducttextlink.click();
		driver.findElement(By.id("back-to-products")).click();
	}
	else
		System.out.println("Product text not found");
}


@Test (priority=13)
public static void isRemovetocartEnable()
{
    removetocart=driver.findElement(By.id("remove-sauce-labs-backpack")); 
    //cartproductcount=driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a"));
	//cartproductcount=driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/span"));
	
	//previouscount=Integer.parseInt(cartproductcount.getText());
    if(removetocart.isEnabled())
		{ System.out.println("Remove to cart of sauce labs backpack is enabled"); removetocart.click();}
	else
		System.out.println("Remove to cart of sauce labs backpack is not enabled");	
    driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a")).click();
}

@Test (priority=14)
public static void isCheckoutEnable()
{
    checkoutcart=driver.findElement(By.id("checkout"));
    checkoutcart.click();
}

@Test (priority=15)
public static void isCustomerEntryFilled()
{
    driver.findElement(By.id("first-name")).sendKeys("ABC");
    driver.findElement(By.id("last-name")).sendKeys("XYZ");
    driver.findElement(By.id("postal-code")).sendKeys("586104");
    driver.findElement(By.id("continue")).click();
    
    
}

@Test (priority=16)
public static void isCustomerClickedOnFinishButton()
{
    driver.findElement(By.id("finish")).click();
}



}
	
	


